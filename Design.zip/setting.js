
if(   window.location === window.parent.location 
      && !(window.location.href).includes('127.0.0.1')
      && !(window.location.href).includes('FlutterBuilder_p5js')
  )
{	  	// The page is not in an iframe or localhost
    alert("You can't access this page directly");
    window.location = "https://less-code.000webhostapp.com";
}
if(window.location.href.includes('000webhostapp'))
    window.onload = () => {
        const body = window.document.children[0].children[1];
        const index = body.children.length - 2;
        const div = body.children[index];
        div.style.display = 'none';
    }
    