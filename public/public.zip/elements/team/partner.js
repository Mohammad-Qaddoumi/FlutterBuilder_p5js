export default class Partner
{
    constructor(name,email)
    {
        this.name = name;
        this.email = email;
        this.X = 0;
        this.Y = 0;
        this.selected  = null;
    }
}
